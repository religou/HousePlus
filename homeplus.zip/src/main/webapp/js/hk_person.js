$(document).ready(function () {
    loginSuccess();
    $(".log-out").click (function () {
        logout();
    })
    showBorder();
    setIFrameHeight();
    $(".list-group-item").click(function () {
        console.log($(this).attr("id"))
        showFrame($(this));
    })
})

function showBorder() {
    $(".list-group-item").click(function () {
        $(this).css({"box-sizing": "border-box", "border-left": "2px solid #fff"})
        $(this).siblings(".list-group-item").css("border", "0px");
    })
}

function showFrame(elem) {
    var src = elem.attr("id") + ".html";
    $("#myIframe").attr("src", src);
}

function loginSuccess() {
    $(".log-out").css({"display": "none"});
    $.ajax({
        "url": "/user/loginSuccess",
        "type": "Post",
        "success": function (json) {
            if (json.state == 200) {
                $(".log-out").css({"display": "block"});
                $(".log-in").css({"display": "none"});
                $(".register").css({"display": "none"});
            }
        }
    })
}

// 退出系统
function logout() {
    $.ajax ({
        "url": "/user/logout",
        "type": "Post",
        "success": function (json) {
            if (json.state == 200) {
                alert("退出成功...");
            }
        }
    })
}

function setIFrameHeight() {
    var browserVersion = window.navigator.userAgent.toUpperCase();
    var isOpera = browserVersion.indexOf("OPERA") > -1 ? true : false;
    var isFireFox = browserVersion.indexOf("FIREFOX") > -1 ? true : false;
    var isChrome = browserVersion.indexOf("CHROME") > -1 ? true : false;
    var isSafari = browserVersion.indexOf("SAFARI") > -1 ? true : false;
    var isIE = (!!window.ActiveXObject || "ActiveXObject" in window);
    var isIE9More = (! -[1, ] == false);


    function reinitIframe(iframeId, minHeight) {
        try {
            var iframe = document.getElementById(iframeId);
            var bHeight = 0;
            if (isChrome == false && isSafari == false)
                bHeight = iframe.contentWindow.document.body.scrollHeight;

            var dHeight = 0;
            if (isFireFox == true)
                dHeight = iframe.contentWindow.document.documentElement.offsetHeight + 2;
            else if (isIE == false && isOpera == false)
                dHeight = iframe.contentWindow.document.documentElement.scrollHeight;
            else if (isIE == true && isIE9More) {//ie9+
                var heightDeviation = bHeight - eval("window.IE9MoreRealHeight" + iframeId);
                if (heightDeviation == 0) {
                    bHeight += 3;
                } else if (heightDeviation != 3) {
                    eval("window.IE9MoreRealHeight" + iframeId + "=" + bHeight);
                    bHeight += 3;
                }
            }
            else//ie[6-8]、OPERA
                bHeight += 3;

            var height = Math.max(bHeight, dHeight);
            if (height < minHeight) height = minHeight;
            iframe.style.height = height + "px";
        } catch (ex) { }
    }
    function startInit(iframeId, minHeight) {
        eval("window.IE9MoreRealHeight" + iframeId + "=0");
        reinitIframe(iframeId, minHeight);
    }
    var minHeight = $(window).height();
    startInit('myIframe', minHeight);
}